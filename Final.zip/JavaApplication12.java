/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication12;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int A;
        
        System.out.print("ingrese un Cantidad");
         Scanner C1 = new Scanner(System.in);
           A = C1.nextInt();
           if (A%2==0) {
               System.out.print("Es Par"); 
           } else{
               System.out.print("Es Impar");
           }
           // Nombre
               String Nombre = "";
               
               System.out.print("Ingrese Nombre");
               Scanner N1 = new Scanner(System.in);
               Nombre = N1.nextLine();
           
    }
}
